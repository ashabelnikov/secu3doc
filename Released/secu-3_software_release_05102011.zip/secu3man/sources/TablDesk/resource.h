//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TablDesk.rc
//
#define IDD_TD_BUTTONS_PANEL            5001
#define IDC_TD_VIEW_START_MAP           5002
#define IDC_TD_VIEW_IDLE_MAP            5003
#define IDC_TD_VIEW_WORK_MAP            5004
#define IDC_TD_VIEW_TEMP_MAP            5005
#define IDD_TD_ALLTABLES_PANEL          5006
#define IDC_TD_VIEW_DWELL_CONTROL       5007
#define IDC_TD_VIEW_ATTENUATOR_MAP      5008
#define IDC_TD_FUNSET_LIST              5009
#define IDC_TD_MAP_GROUPBOX             5010
#define IDS_MAPS_RPM_UNIT               5011
#define IDS_MAPS_ADVANGLE_UNIT          5012                                      
#define IDS_START_MAP                   5013
#define IDS_IDLE_MAP                    5014
#define IDS_WORK_MAP                    5015
#define IDS_TEMPCORR_MAP                5016
#define IDS_MAPS_TEMPERATURE_UNIT       5017
#define IDS_MAPS_ATTENUATOR_GAIN_UNIT   5018
#define IDS_ATTENUATOR_MAP              5019
#define IDS_MAPS_VOLT_UNIT              5020
#define IDS_MAPS_DWELLCNTRL_UNIT        5021
#define IDS_DWELLCNTRL_MAP              5022

