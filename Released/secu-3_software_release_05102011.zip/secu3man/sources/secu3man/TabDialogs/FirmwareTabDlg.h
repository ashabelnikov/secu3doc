/* SECU-3  - An open source, free engine control unit
   Copyright (C) 2007 Alexey A. Shabelnikov. Ukraine, Gorlovka

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.

   contacts:
              http://secu-3.org
              email: shabelnikov@secu-3.org
*/

#pragma once

#include <memory>
#include <vector>
#include "common/FastDelegate.h"
#include "ui-core/TabDialog.h"

class CHotKeysToCmdRouter;
class CFirmwareModeContextMenuManager;
class CParamDeskDlg;
class CTablesSetPanel;

/////////////////////////////////////////////////////////////////////////////
// CFirmwareTabDlg dialog

class CFirmwareTabDlg : public CTabDialog
{
  typedef CTabDialog Super;
  typedef fastdelegate::FastDelegate0<> EventHandler;
  typedef fastdelegate::FastDelegate0<bool> EventResult;

 public:
  CFirmwareTabDlg(CWnd* pParent = NULL);   // standard constructor

  static const UINT IDD;

  virtual LPCTSTR GetDialogID(void) const;

  bool IsBLStartedEmergency(void);
  void SetBLStartedEmergency(bool state);

  void EnableBLStartedEmergency(bool enable);
  bool IsBLStartedEmergencyEnabled(void);

  void EnableBLItems(bool enable);
  bool IsBLItemsEnabled(void);

  void EnableAppItems(bool enable);
  bool IsAppItemsEnabled(void);

  void SetFWInformationText(CString i_text);
  CString GetFWInformationText(void);

  void SetFirmwareName(_TSTRING i_name);
  void SetModified(bool i_modified);
  void SetFirmwareCRCs(unsigned int crc_stored_in_fw, unsigned int actual_crc_of_fw);

  bool IsProgrammeOnlyCode(void);

  std::auto_ptr<CParamDeskDlg> mp_ParamDeskDlg;
  std::auto_ptr<CFirmwareModeContextMenuManager> mp_ContextMenuManager;
  std::auto_ptr<CTablesSetPanel> mp_TablesPanel;

 public: //��������� ������������ ������� �� ����
  void setOnBootLoaderInfo(EventHandler OnFunction);
  void setOnReadEepromToFile(EventHandler OnFunction);
  void setOnWriteEepromFromFile(EventHandler OnFunction);
  void setOnReadFlashToFile(EventHandler OnFunction);
  void setOnWriteFlashFromFile(EventHandler OnFunction);
  void setOnOpenFlashFromFile(EventHandler OnFunction);
  void setOnFWInformationTextChanged(EventHandler OnFunction);
  void setOnSaveFlashToFile(EventHandler OnFunction);
  void setIsFirmwareOpened(EventResult IsFunction);
  void setOnImportDataFromAnotherFW(EventHandler OnFunction);
  void setOnReadFlashFromSECU(EventHandler OnFunction);
  void setOnWriteFlashToSECU(EventHandler OnFunction);
  void setOnImportDataFromSECU3(EventHandler OnFunction);
  void setOnImportMapsFromMPSZ(EventHandler OnFunction);
  void setOnImportMapsFromSECU3(EventHandler OnFunction);
  void setOnImportDefParamsFromEEPROMFile(EventHandler OnFunction);
  void setOnImportTablesFromEEPROMFile(EventHandler OnFunction);
  void setOnExportMapsToMPSZ(EventHandler OnFunction);
  void setOnExportMapsToSECU3(EventHandler OnFunction);
  void setOnFirmwareInfo(EventHandler OnFunction);
  void setOnViewFWOptions(EventHandler OnFunction);
  void setIsViewFWOptionsAvailable(EventResult OnFunction);
  //... �� ������ � ��� ������
  void setOnBLStartedEmergency(EventHandler OnFunction);

// Implementation
 protected:
  virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
  virtual BOOL OnInitDialog();
  afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
  afx_msg void OnUpdatePopupMenu_bl(CCmdUI* pCmdUI);
  afx_msg void OnUpdatePopupMenu_file(CCmdUI* pCmdUI);
  afx_msg void OnUpdatePopupMenu_file1(CCmdUI* pCmdUI);
  afx_msg void OnUpdatePopupMenu_app(CCmdUI* pCmdUI);
  afx_msg void OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu);
  afx_msg void OnUpdateFirmwareSupportViewFWOptions(CCmdUI* pCmdUI);
  afx_msg void OnTimer(UINT nIDEvent);
  afx_msg void OnDestroy();
  afx_msg void OnBootLoaderInfo();
  afx_msg void OnReadEepromToFile();
  afx_msg void OnWriteEepromFromFile();
  afx_msg void OnReadFlashToFile();
  afx_msg void OnWriteFlashFromFile();
  afx_msg void OnUpdateBLStartedEmergency(CCmdUI* pCmdUI);
  afx_msg void OnFirmwareSupportBlStartedEmergency();
  afx_msg void OnOpenFlashFromFile();
  afx_msg void OnSaveFlashToFile();
  afx_msg void OnChangeFirmwareSupportFwInformation();
  afx_msg void OnUpdateFirmwareControls(CCmdUI* pCmdUI);
  afx_msg void OnImportDataFromAnotherFW();
  afx_msg void OnReadFlashFromSECU();
  afx_msg void OnWriteFlashToSECU();
  afx_msg void OnImportDataFromSECU3();
  afx_msg void OnUpdateProgOnlyCode(CCmdUI* pCmdUI);
  afx_msg void OnImportMapsFromMPSZ();
  afx_msg void OnImportMapsFromSECU3();
  afx_msg void OnImportDefParamsFromEEPROMFile();
  afx_msg void OnImportTablesFromEEPROMFile();
  afx_msg void OnExportMapsToMPSZ();
  afx_msg void OnExportMapsToSECU3();
  afx_msg void OnFirmwareInfo();
  afx_msg void OnViewFWOptions();
  DECLARE_MESSAGE_MAP()

 private:
  CButton   m_bl_started_emergency;
  CButton   m_prog_only_code_checkbox;
  CButton   m_fw_options_btn;
  CEdit     m_fw_information_edit;
  CEdit     m_fw_name;
  CStatic   m_fw_crc;
  CStatic   m_modification_flag;

 private:
  EventHandler  m_OnBootLoaderInfo;
  EventHandler  m_OnReadEepromToFile;
  EventHandler  m_OnWriteEepromFromFile;
  EventHandler  m_OnReadFlashToFile;
  EventHandler  m_OnWriteFlashFromFile;
  EventHandler  m_OnBLStartedEmergency;
  EventHandler  m_OnOpenFlashFromFile;
  EventHandler  m_OnSaveFlashToFile;
  EventHandler  m_OnFWInformationTextChanged;
  EventHandler  m_OnImportDataFromAnotherFW;
  EventHandler  m_OnReadFlashFromSECU;
  EventHandler  m_OnWriteFlashToSECU;
  EventHandler  m_OnImportDataFromSECU3;
  EventHandler  m_OnImportMapsFromMPSZ;
  EventHandler  m_OnImportMapsFromSECU3;
  EventHandler  m_OnImportDefParamsFromEEPROMFile;
  EventHandler  m_OnImportTablesFromEEPROMFile;
  EventHandler  m_OnExportMapsToMPSZ;
  EventHandler  m_OnExportMapsToSECU3;
  EventHandler  m_OnFirmwareInfo;
  EventHandler  m_OnViewFWOptions;
  EventResult   m_IsFirmwareOpened;
  EventResult   m_IsViewFWOptionsAvailable;

  bool IsFirmwareOpened(void);

  bool m_is_bl_started_emergency_available;
  bool m_is_bl_items_available;
  bool m_is_app_items_available;

  void _RegisterHotKeys(void);
  std::auto_ptr<CHotKeysToCmdRouter> m_hot_keys_supplier;
};
