//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MIdesk.rc
//
#define IDC_MI_AIR_FLOW                 2001
#define IDC_MI_GAS_VALVE                2002
#define IDC_MI_THROTTLE_GATE            2003
#define IDC_MI_SHUTOFF_VALVE            2004
#define IDC_MI_GAS_VALVE_CAPTION        2005
#define IDC_MI_THROTTLE_GATE_CAPTION    2006
#define IDC_MI_SHUTOFF_VALVE_CAPTION    2007
#define IDC_MI_AIR_FLOW_NUM             2008
#define IDC_MI_AIR_FLOW_CAPTION         2009
#define IDC_MI_TACHOMETER               2010
#define IDC_MI_MAP                      2011
#define IDC_MI_VOLTMETER                2012
#define IDC_MI_DWELL_ANGLE              2013
#define IDC_MI_TEMPERATURE              2014
#define IDD_MEAS_INSTRUMENT_DESK        2015
#define IDD_RAW_SENSORS_DESK            2016
#define IDC_RS_MAP_VALUE                2017
#define IDC_RS_MAP_UNIT                 2018
#define IDC_RS_MAP_CAPTION              2019
#define IDC_RS_UBAT_VALUE               2020
#define IDC_RS_UBAT_CAPTION             2021
#define IDC_RS_UBAT_UNIT                2022
#define IDC_RS_TEMP_VALUE               2023
#define IDC_RS_TEMP_CAPTION             2024
#define IDC_RS_TEMP_UNIT                2025
#define IDC_RS_KNOCK_VALUE              2026
#define IDC_RS_KNOCK_CAPTION            2027
#define IDC_RS_KNOCK_UNIT               2028
#define IDS_MI_VOLTAGE_TITLE            2029
#define IDS_MI_VOLTAGE_UNIT             2030
#define IDS_MI_TEMPERATURE_TITLE        2031
#define IDS_MI_TEMPERATURE_UNIT         2032
#define IDS_MI_TACHOMETER_TITLE         2033
#define IDS_MI_TACHOMETER_UNIT          2034
#define IDS_MI_PRESSURE_TITLE           2035
#define IDS_MI_PRESSURE_UNIT            2036
#define IDS_MI_ADVANGLE_TITLE           2037
#define IDS_MI_ADVANGLE_UNIT            2038

