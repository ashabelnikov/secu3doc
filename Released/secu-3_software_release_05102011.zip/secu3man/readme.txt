    SECU-3 Management software. Distributed under GPL license

    Created using Microsoft Visual Studio 6.0 & Borlad C++ Builder 5.0

    Designed by Alexey A. Shabelnikov 2007. Ukraine, Gorlovka.
    Microprocessors systems - design & programming.
    http://secu-3.org e-mail: shabelnikov@secu-3.org


      How to compile the project

    To compile the project, open workspace /sources/secu3man/secu3man.dsw
