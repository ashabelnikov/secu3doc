
#pragma once

class AFX_EXT_CLASS CProgressCtrlEx : public CProgressCtrl
{
 public:
  CProgressCtrlEx();
  virtual ~CProgressCtrlEx();

 protected:
  // Generated message map functions
  afx_msg void OnPaint();
  DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
