//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by uicore.rc
//

