//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FWImpExp.rc
//
#define IDD_MAP_IMPEXP                  6000
#define IDC_MAP_IMPEXP_CURRENT_FWD_LIST 6000
#define IDC_MAP_IMPEXP_OTHER_FWD_LIST   6001
#define IDC_MAP_IMPEXP_EXCHANGE_BUTTON  6002
#define IDC_MAP_IMPEXP_STARTMAP_FLAG    6003
#define IDC_MAP_IMPEXP_IDLEMAP_FLAG     6004
#define IDC_MAP_IMPEXP_WORKMAP_FLAG     6005
#define IDC_MAP_IMPEXP_TEMPMAP_FLAG     6006
#define IDC_MAP_IMPEXP_CURRENT_FWD_TITLE 6007
#define IDC_MAP_IMPEXP_OTHER_FWD_TITLE  6008
#define IDS_CANT_LOAD_THIS_FILE         6009
#define IDS_MAP_NO_NAME                 6010
#define IDS_SECU3_CURRENT_FW            6011
#define IDS_MPSZ_FW_FILE                6012
#define IDS_IMPORT_MPSZ_TABLES          6013
#define IDS_CANT_SAVE_THIS_FILE         6014
#define IDS_EXPORT_MPSZ_TABLES          6015

