#define IDB_BITMAP0001                  1000
#define IDR_RGN0001                     1001
#define IDS_SOFTWARE_INFO               1002
#define IDS_AUTHOR_INFO                 1003
#define IDC_BUTTON_CLOSE                1004
