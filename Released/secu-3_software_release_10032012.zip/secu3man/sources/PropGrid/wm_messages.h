// Messages used in property grid and related contrls


#define WM_PG_START (WM_USER + 486)

#define WM_PG_ITEMCHANGED        WM_PG_START + 0
#define WM_PG_COMBOSELCHANGED    WM_PG_START + 1
#define WM_PG_ENDLABELEDIT       WM_PG_START + 2
#define WM_PG_DATESELCHANGED     WM_PG_START + 3
#define WM_PG_SELECTORSELCHANGED WM_PG_START + 4
