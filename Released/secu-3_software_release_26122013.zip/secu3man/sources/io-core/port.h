
#if !defined(_WIN32)
 #include <stdint.h>
 #include <pthread.h>
 //Critical sections
 #define CRITICAL_SECTION pthread_mutex_t
// typedef pthread_mutex_t CRITICAL_SECTION;

 #define EnterCriticalSection(obj) pthread_mutex_lock((obj))
 #define LeaveCriticalSection(obj) pthread_mutex_unlock((obj))
 #define InitializeCriticalSection(obj) pthread_mutex_init((obj), NULL)
 #define DeleteCriticalSection(obj) pthread_mutex_destroy((obj))
 //Types
 #define WINAPI
 #define FALSE 0
 #define TRUE  1
 typedef int HANDLE;
 typedef uint8_t BYTE;
 typedef uint32_t DWORD;
 typedef void* LPVOID;
 typedef unsigned int UINT;
 typedef void VOID;
#endif