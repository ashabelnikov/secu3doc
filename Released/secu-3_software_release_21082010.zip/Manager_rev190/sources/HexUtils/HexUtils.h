// HexUtils.h : main header file for the HEXUTILS DLL
//

#pragma once

#ifndef __AFXWIN_H__
 #error include 'stdafx.h' before including this file for PCH
#endif

/////////////////////////////////////////////////////////////////////////////
// CHexUtilsApp
// See HexUtils.cpp for the implementation of this class
//

class CHexUtilsApp : public CWinApp
{
 public:
  CHexUtilsApp();

  DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
