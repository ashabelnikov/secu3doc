//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PROPGRID.RC
//

#define IDC_LIST_DYN_DLGEX_LIST1 9000
