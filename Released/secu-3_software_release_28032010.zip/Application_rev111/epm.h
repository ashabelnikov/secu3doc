
#ifndef _EPM_H_
#define _EPM_H_

struct ecudata;

void epm_init_ports(void);

void epm_control(struct ecudata* d);

#endif //_EPM_H_
