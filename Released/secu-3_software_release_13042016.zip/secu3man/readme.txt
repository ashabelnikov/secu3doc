    SECU-3 Management software. Distributed under GPL license

    Designed by Alexey A. Shabelnikov 2007. Ukraine, Kiev.
    Microprocessor systems - design & programming.
    http://secu-3.org e-mail: shabelnikov@secu-3.org


      How to compile the project
      ��� ������������� ������

    1. Prerequisites: Visual Studio >= 6.0, CBuilder >= 5.0, CMake >= 2.6
       (http://www.cmake.org/cmake/resources/software.html).

    2. Make sure CMake is in your system PATH variable.

    3. Run configure.bat. This will generate build environment for you.

    4. Project is ready to build (e.g. open project using Visual Studio).
